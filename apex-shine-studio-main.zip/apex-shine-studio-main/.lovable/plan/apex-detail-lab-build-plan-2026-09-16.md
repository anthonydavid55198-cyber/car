# Apex Detail Lab — Build Plan

## Experience
- Build a dark, high-performance single-page studio experience at `/` with graphite surfaces, metallic detailing, carbon-fiber texture, and cyan/lime action accents.
- Create a compact studio header, dramatic transformation-led opening section, service portfolio, custom package builder, reviews, and booking flow.
- Use responsive layouts for phone, tablet, standard desktop, and widescreen screens, with reduced-motion support and careful image loading.

## Interactive Features
- Add a draggable before/after paint transformation slider with touch, mouse, and keyboard controls.
- Build a three-stage package configurator:
  1. Select vehicle class and price multiplier.
  2. Toggle detailing modules and correction stages.
  3. Review a live sticky estimate for total price and turnaround time.
- Add a filterable service portfolio with detailed modal views covering inclusions, durability, and warranty.
- Add a multi-step booking modal prefilled from the package builder, field validation, preferred date selection, submission progress, and animated confirmation code.

## Data and Booking
- Create `vehicles`, `services`, and `bookings` tables with explicit access grants and row-level security.
- Seed representative vehicle classes and a rich service catalogue directly in the database migration.
- Keep catalogue reads public and limited to safe fields; allow public booking creation while preventing public booking reads or edits.
- Submit bookings through validated server-side logic and return a generated confirmation code without exposing private customer records.

## Visual Assets and Motion
- Generate a cohesive pair of luxury sports-car paint images for the transformation comparison.
- Add locally bundled detailing imagery for portfolio cards rather than external hotlinks.
- Use staggered entrances, restrained card tilt, metallic border glows, button feedback, modal transitions, and animated success states.
- Keep motion subtle and disable nonessential effects when reduced motion is requested.

## Technical Details
- Use TanStack Start, React 19, Tailwind v4 semantic tokens, existing design-system controls, and Motion for React.
- Add route-specific title, description, Open Graph, and Twitter metadata.
- Split the experience into focused components and keep pricing rules in one typed module.
- Validate the final flow in the live preview across desktop and mobile, including slider dragging, filtering, package calculations, modal navigation, and booking submission.
