CREATE TABLE public.vehicles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  make TEXT NOT NULL,
  model TEXT NOT NULL,
  year INTEGER NOT NULL CHECK (year BETWEEN 1950 AND 2100),
  category TEXT NOT NULL CHECK (category IN ('sports', 'sedan', 'suv', 'exotic'))
);
GRANT SELECT ON public.vehicles TO anon, authenticated;
GRANT ALL ON public.vehicles TO service_role;
ALTER TABLE public.vehicles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Vehicle catalogue is publicly readable" ON public.vehicles FOR SELECT TO anon, authenticated USING (true);

CREATE TABLE public.services (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE,
  description TEXT NOT NULL,
  base_price NUMERIC(10,2) NOT NULL CHECK (base_price >= 0),
  estimated_hours NUMERIC(5,1) NOT NULL CHECK (estimated_hours > 0),
  category TEXT NOT NULL CHECK (category IN ('paint-correction', 'ceramic-coatings', 'interior-restoration', 'track-day-prep'))
);
GRANT SELECT ON public.services TO anon, authenticated;
GRANT ALL ON public.services TO service_role;
ALTER TABLE public.services ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Service catalogue is publicly readable" ON public.services FOR SELECT TO anon, authenticated USING (true);

CREATE TABLE public.bookings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_name TEXT NOT NULL,
  customer_email TEXT NOT NULL,
  customer_phone TEXT NOT NULL,
  vehicle_info TEXT NOT NULL,
  selected_services JSONB NOT NULL DEFAULT '[]'::jsonb,
  total_price NUMERIC(10,2) NOT NULL CHECK (total_price >= 0),
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'confirmed', 'in-bay', 'completed')),
  scheduled_date DATE NOT NULL,
  confirmation_code TEXT NOT NULL UNIQUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT INSERT ON public.bookings TO anon, authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.bookings TO service_role;
ALTER TABLE public.bookings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone may request a booking" ON public.bookings FOR INSERT TO anon, authenticated WITH CHECK (status = 'pending');

CREATE INDEX services_category_idx ON public.services(category);
CREATE INDEX bookings_scheduled_date_idx ON public.bookings(scheduled_date);