# Apex Shine Studio

Build a high-performance, dark-mode-first web application for a luxury automotive detailing studio called "Apex Detail Lab".

1. Visual Aesthetic & Animations:

- Design System: Dark graphite backgrounds (#0A0A0C), metallic silver accents, subtle carbon-fiber texture gradients, and high-visibility neon cyan/lime highlights for CTAs.

- Animations (using Framer Motion / Tailwind animate):

  * Staggered entrance animations on page load for headers and cards.

  * Subtle hover-lift physics on service tier cards with dynamic border glows.

  * Smooth micro-interactions for buttons, tabs, and interactive sliders.

2. Key Pages & Interactive Features:

- Hero Section:

  * Sleek typography with automotive-inspired styling.

  * Interactive "Before / After Transformation" Slider: A responsive image comparison slider featuring a swirl-marked/dull sports car paint vs. a mirror-finish ceramic coated gloss finish. Users can drag the divider back and forth.

  * Primary CTA: "Build Your Detail Package" (smooth-scrolls to the custom builder).

- Interactive Custom Package Builder (Dynamic Cost & Time Estimator):

  * Step 1: Vehicle Size Selection (Coupe/Sedan, SUV/Truck, Exotic/Supercar) with distinct price multipliers.

  * Step 2: Detailing Modules (Paint Correction Stage 1/2/3, Multi-Year Ceramic Coating, PPF Paint Protection Film, Deep Interior Steam & Leather Conditioning, Engine Bay Detail).

  * Step 3: Live Summary Drawer/Sticky Card displaying estimated turnaround time (hours/days) and dynamically calculated total price in real time.

- Service Portfolio & Grid:

  * Filterable gallery (Paint Correction, Ceramic Coatings, Interior Restoration, Track-Day Prep).

  * Modal detail view when clicking any service card, showing package inclusions, durability ratings, and warranty specs.

- Booking & Scheduling System:

  * Step-by-step booking modal connected to Supabase:

    * Fields: Owner Name, Email, Phone, Vehicle Make/Model/Year, Selected Services (pre-filled from builder), Preferred Drop-off Date.

  * Confirmation screen with an animated success state and simulated appointment confirmation code.

3. Database Architecture (Supabase):

- vehicles (id, make, model, year, category: sports/sedan/suv/exotic)

- services (id, name, description, base_price, estimated_hours, category)

- bookings (id, customer_name, customer_email, customer_phone, vehicle_info, total_price, status: pending/confirmed/in-bay/completed, scheduled_date, created_at)

4. Polish & Edge Cases:

- Fully responsive across mobile, tablet, and widescreen viewports.

- Pre-populate rich mock data for services, pricing, customer reviews, and high-quality Unsplash car detailing imagery so the site is visually complete immediately.

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/6c3f9044-f8fe-40f8-a02d-93cf530a35a6).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
