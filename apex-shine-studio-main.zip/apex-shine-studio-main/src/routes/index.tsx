import { createFileRoute } from "@tanstack/react-router";
import { ApexDetailLab } from "@/components/ApexDetailLab";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Apex Detail Lab | Precision Automotive Care" },
      {
        name: "description",
        content:
          "Precision paint correction, ceramic protection, and interior care for discerning drivers in Los Angeles.",
      },
      { property: "og:title", content: "Apex Detail Lab | Finish Redefined" },
      {
        property: "og:description",
        content:
          "A considered approach to automotive detailing, protection, and the details that last.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ApexDetailLab,
});
