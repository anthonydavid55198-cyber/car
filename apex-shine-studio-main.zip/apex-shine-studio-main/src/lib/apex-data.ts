import servicePaint from "@/assets/service-paint.jpg";
import serviceCeramic from "@/assets/service-ceramic.jpg";
import serviceInterior from "@/assets/service-interior.jpg";
import serviceTrack from "@/assets/service-track.jpg";

export type VehicleSize = "coupe" | "suv" | "exotic";
export type ServiceCategory = "all" | "paint" | "ceramic" | "interior" | "track";

export const studioContact = {
  phone: "+1 (310) 555-0188",
  email: "hello@apexdetaillab.com",
  address: "48 Meridian Avenue, Los Angeles, CA 90021",
  hours: "Mon–Sat · 8:00–18:00",
};

export const vehicleSizes = [
  { id: "coupe" as const, name: "Coupe / Sedan", note: "2–5 seats", multiplier: 1 },
  { id: "suv" as const, name: "SUV / Truck", note: "Extended surface area", multiplier: 1.25 },
  {
    id: "exotic" as const,
    name: "Exotic / Supercar",
    note: "Specialized protocols",
    multiplier: 1.45,
  },
];

export const modules = [
  {
    id: "stage1",
    name: "Stage 1 Correction",
    detail: "Gloss enhancement · light defects",
    price: 650,
    hours: 8,
    group: "correction",
  },
  {
    id: "stage2",
    name: "Stage 2 Correction",
    detail: "Deep swirls · near-flawless clarity",
    price: 1100,
    hours: 14,
    group: "correction",
  },
  {
    id: "stage3",
    name: "Stage 3 Correction",
    detail: "Concours refinement · wet sanding",
    price: 1850,
    hours: 24,
    group: "correction",
  },
  {
    id: "ceramic",
    name: "5-Year Ceramic Coating",
    detail: "9H protection · extreme hydrophobics",
    price: 1200,
    hours: 12,
  },
  {
    id: "ppf",
    name: "Front-End PPF",
    detail: "Self-healing impact protection",
    price: 2400,
    hours: 18,
  },
  {
    id: "interior",
    name: "Interior Atelier",
    detail: "Steam extraction · leather conditioning",
    price: 475,
    hours: 6,
  },
  {
    id: "engine",
    name: "Engine Bay Detail",
    detail: "Low-moisture precision cleaning",
    price: 275,
    hours: 3,
  },
];

export const portfolio = [
  {
    id: "paint",
    category: "paint" as const,
    title: "Optical Clarity Protocol",
    kicker: "Paint correction",
    image: servicePaint,
    price: "From $650",
    durability: "Permanent correction",
    warranty: "12-month workmanship",
    inclusions: [
      "Digital paint-depth mapping",
      "Multi-angle defect inspection",
      "Panel-specific machine polishing",
      "Infrared final inspection",
    ],
  },
  {
    id: "ceramic",
    category: "ceramic" as const,
    title: "Molecular Shield",
    kicker: "Ceramic coating",
    image: serviceCeramic,
    price: "From $1,200",
    durability: "Up to 5 years",
    warranty: "5-year registered warranty",
    inclusions: [
      "Full chemical decontamination",
      "Paint refinement included",
      "9H nano-ceramic application",
      "Wheel face and glass coating",
    ],
  },
  {
    id: "interior",
    category: "interior" as const,
    title: "Cabin Atelier",
    kicker: "Interior restoration",
    image: serviceInterior,
    price: "From $475",
    durability: "6–12 months",
    warranty: "30-day satisfaction",
    inclusions: [
      "Vapor steam sanitation",
      "Leather pH cleansing",
      "UV-resistant conditioning",
      "Textile extraction and protection",
    ],
  },
  {
    id: "track",
    category: "track" as const,
    title: "Circuit Readiness",
    kicker: "Track-day prep",
    image: serviceTrack,
    price: "From $825",
    durability: "Event-specific",
    warranty: "Pre-event inspection",
    inclusions: [
      "Wheel well and brake detailing",
      "Track film removal",
      "High-impact PPF assessment",
      "Post-session decontamination",
    ],
  },
];

export const reviews = [
  {
    quote:
      "The paint has depth I genuinely did not know was possible. Their lighting inspection and handover were obsessive.",
    name: "Marcus T.",
    car: "Porsche 992 GT3",
    initials: "MT",
  },
  {
    quote:
      "Apex returned my car in concours condition and documented every panel. The standard here is on another level.",
    name: "Elena R.",
    car: "Ferrari Roma",
    initials: "ER",
  },
  {
    quote:
      "Track rubber, brake dust, and a tired cabin—gone. It looked collection-ready again in two days.",
    name: "James K.",
    car: "McLaren 720S",
    initials: "JK",
  },
];

export function calculateEstimate(vehicle: VehicleSize, selected: string[]) {
  const multiplier = vehicleSizes.find((item) => item.id === vehicle)?.multiplier ?? 1;
  const chosen = modules.filter((item) => selected.includes(item.id));
  return {
    price: Math.round(chosen.reduce((sum, item) => sum + item.price, 0) * multiplier),
    hours: Math.ceil(
      chosen.reduce((sum, item) => sum + item.hours, 0) * Math.max(1, multiplier - 0.05),
    ),
    names: chosen.map((item) => item.name),
  };
}
