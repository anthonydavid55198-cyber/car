import { motion, useReducedMotion } from "motion/react";
import {
  ArrowUpRight,
  Check,
  Mail,
  MapPin,
  Phone,
  ScanLine,
  ShieldCheck,
  Sparkles,
} from "lucide-react";
import heroImage from "@/assets/apex-bmw-hero.jpg";
import logoCompact from "@/assets/apex-logo-compact.png";
import servicePaint from "@/assets/service-paint.jpg";
import serviceCeramic from "@/assets/service-ceramic.jpg";
import serviceInterior from "@/assets/service-interior.jpg";
import serviceTrack from "@/assets/service-track.jpg";
import { studioContact } from "@/lib/apex-data";

const reveal = {
  hidden: { opacity: 0, y: 24 },
  show: { opacity: 1, y: 0 },
};

const services = [
  {
    number: "01",
    title: "Paint correction",
    description:
      "Remove the visual noise. Restore depth, clarity, and a clean reflection across every panel.",
    image: servicePaint,
    alt: "Detailer towel on a freshly polished red car panel",
  },
  {
    number: "02",
    title: "Ceramic protection",
    description:
      "A durable molecular shield that keeps the finish sharper, cleaner, and easier to live with.",
    image: serviceCeramic,
    alt: "Glossy black car paint catching a warm studio reflection",
  },
  {
    number: "03",
    title: "Interior atelier",
    description:
      "Steam, leather, and textile care for the part of the car you experience every mile.",
    image: serviceInterior,
    alt: "Detailer steam-cleaning the interior of a luxury sports car",
  },
  {
    number: "04",
    title: "Track preparation",
    description:
      "A focused reset for cars that see the circuit: clean, inspect, and ready for the next session.",
    image: serviceTrack,
    alt: "Track-focused sports car detailing and preparation",
  },
];

const principles = [
  "Color-accurate lighting inspection",
  "Panel-by-panel correction planning",
  "Documented handover, without the theatre",
];

export function ApexDetailLab() {
  const reduced = useReducedMotion();
  const telHref = `tel:${studioContact.phone.replace(/[^+\d]/g, "")}`;
  const mailHref = `mailto:${studioContact.email}`;

  return (
    <div className="min-h-screen overflow-x-hidden bg-background text-foreground">
      <header className="fixed inset-x-0 top-0 z-50 border-b border-white/10 bg-[#070b13]/80 backdrop-blur-xl">
        <div className="mx-auto flex h-[76px] max-w-screen-2xl items-center justify-between px-5 sm:px-8 lg:px-12">
          <a href="#top" className="flex items-center gap-3" aria-label="Apex Detail Lab home">
            <img
              src={logoCompact}
              alt=""
              className="h-14 w-14 object-contain drop-shadow-[0_0_16px_var(--highlight-glow)]"
            />
            <span className="font-display text-sm font-bold uppercase tracking-[.2em]">
              Apex <span className="text-muted-foreground">Detail Lab</span>
            </span>
          </a>
          <nav
            className="hidden items-center gap-8 text-[11px] font-semibold uppercase tracking-[.18em] text-muted-foreground md:flex"
            aria-label="Main navigation"
          >
            <a href="#method" className="transition-colors hover:text-highlight">
              Method
            </a>
            <a href="#services" className="transition-colors hover:text-highlight">
              Services
            </a>
            <a href="#contact" className="transition-colors hover:text-highlight">
              Contact
            </a>
          </nav>
          <p className="hidden text-[10px] font-semibold uppercase tracking-[.18em] text-highlight sm:block">
            Los Angeles · By appointment
          </p>
        </div>
      </header>

      <main id="top">
        <section className="relative isolate overflow-hidden bg-[#070b13] pt-[76px]">
          <div className="absolute inset-0 opacity-80 [background-image:linear-gradient(rgba(255,255,255,.04)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,.04)_1px,transparent_1px)] [background-size:72px_72px] [mask-image:linear-gradient(90deg,black,transparent_78%)]" />
          <div className="absolute -left-32 top-40 h-80 w-80 rounded-full bg-cyan-400/10 blur-3xl" />
          <div className="relative mx-auto min-h-[740px] max-w-screen-2xl">
            <motion.div
              initial={false}
              animate="show"
              transition={{ staggerChildren: reduced ? 0 : 0.1 }}
              className="relative z-10 flex flex-col justify-center px-5 py-20 sm:px-8 lg:px-12 lg:py-28"
            >
              <motion.div
                variants={reveal}
                className="mb-7 flex items-center gap-3 text-[11px] font-semibold uppercase tracking-[.24em] text-highlight"
              >
                <span className="h-px w-12 bg-highlight" /> Precision automotive care
              </motion.div>
              <motion.h1
                variants={reveal}
                className="max-w-3xl font-display text-[4.35rem] font-semibold leading-[.88] tracking-[-.055em] text-[#f2eee5] sm:text-[6.8rem] lg:-mr-24 lg:text-[7.8rem]"
              >
                Finish.
                <br />
                <em className="font-serif font-medium text-metallic">redefined.</em>
              </motion.h1>
              <motion.p
                variants={reveal}
                className="mt-8 max-w-md border-l border-highlight/70 pl-5 text-[15px] leading-7 text-foreground/65"
              >
                Experience the prestige of a professionally detailed car, radiating elegance and
                refinement at every turn. Paint correction, ceramic protection, and interior care
                for owners who notice the difference.
              </motion.p>
              <motion.a
                variants={reveal}
                href="#contact"
                className="group mt-9 inline-flex w-fit items-center gap-3 rounded-full border border-highlight/70 bg-highlight px-6 py-4 text-xs font-bold uppercase tracking-[.18em] text-highlight-foreground shadow-[0_14px_40px_var(--highlight-glow)] transition-all duration-200 hover:-translate-y-1 hover:bg-highlight-strong active:translate-y-0"
              >
                Contact us
                <ArrowUpRight className="h-4 w-4 transition-transform duration-200 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
              </motion.a>
              <motion.div
                variants={reveal}
                className="mt-16 grid max-w-md grid-cols-3 border-y border-white/10 py-5 text-[10px] uppercase tracking-[.14em] text-muted-foreground"
              >
                <span>
                  <strong className="block font-mono text-lg font-normal text-foreground">
                    06
                  </strong>{" "}
                  service bays
                </span>
                <span>
                  <strong className="block font-mono text-lg font-normal text-foreground">
                    5 yr
                  </strong>{" "}
                  coating warranty
                </span>
                <span>
                  <strong className="block font-mono text-lg font-normal text-foreground">
                    1:1
                  </strong>{" "}
                  handover
                </span>
              </motion.div>
            </motion.div>

            <motion.div
              initial={false}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: reduced ? 0 : 0.9 }}
              className="absolute inset-0 overflow-hidden border-b border-white/10"
            >
              <img
                src={heroImage}
                alt="Pitch-black BMW with illuminated halo headlights in a reflective detailing studio"
                width={2560}
                height={1440}
                fetchPriority="high"
                className="absolute inset-0 h-full w-full object-cover object-center brightness-[.92] contrast-[1.08] grayscale-[.08]"
              />
              <div className="absolute inset-0 bg-[linear-gradient(90deg,#070b13_0%,rgba(7,11,19,.78)_28%,rgba(7,11,19,.18)_58%,transparent_86%),linear-gradient(0deg,rgba(7,11,19,.7),transparent_48%)]" />
              <div className="absolute inset-x-6 bottom-6 flex items-center justify-between text-[10px] uppercase tracking-[.22em] text-white/55 sm:inset-x-8 lg:inset-x-12">
                <span className="flex items-center gap-3">
                  <span className="h-px w-10 bg-highlight" /> Finish study / 01
                </span>
                <span>Los Angeles / CA</span>
              </div>
            </motion.div>
          </div>
        </section>

        <section
          id="method"
          className="scroll-mt-20 border-b border-border bg-surface py-20 sm:py-28"
        >
          <div className="mx-auto grid max-w-screen-2xl gap-12 px-5 sm:px-8 lg:grid-cols-[.95fr_1.05fr] lg:items-center lg:gap-20 lg:px-12">
            <div>
              <p className="font-mono text-xs text-highlight">01 / The method</p>
              <h2 className="mt-5 max-w-xl font-display text-4xl font-semibold leading-[.88] tracking-[-.055em] text-[#f2eee5] sm:text-6xl">
                Quiet work.
                <br />
                <span className="text-metallic">Loud results.</span>
              </h2>
              <p className="mt-7 max-w-lg text-sm leading-7 text-muted-foreground">
                The studio is designed around observation first: controlled light, measured
                correction, and a finish that looks right from every angle—not just in a photo.
              </p>
              <div className="mt-9 space-y-4">
                {principles.map((principle) => (
                  <div
                    key={principle}
                    className="flex items-center gap-3 text-sm text-foreground/80"
                  >
                    <span className="grid h-6 w-6 place-items-center rounded-full border border-highlight/60 text-highlight">
                      <Check className="h-3.5 w-3.5" />
                    </span>
                    {principle}
                  </div>
                ))}
              </div>
            </div>
            <div className="relative min-h-[420px] overflow-hidden border border-border-strong bg-background">
              <img
                src={serviceCeramic}
                alt="Dark glossy vehicle panel reflecting the studio lights"
                width={1600}
                height={1000}
                loading="lazy"
                className="absolute inset-0 h-full w-full object-cover brightness-[.82]"
              />
              <div className="absolute inset-0 bg-[linear-gradient(135deg,rgba(9,10,12,.8),transparent_56%),linear-gradient(0deg,rgba(9,10,12,.58),transparent_48%)]" />
              <div className="absolute left-6 top-6 flex items-center gap-3 text-[10px] font-semibold uppercase tracking-[.2em] text-highlight sm:left-8 sm:top-8">
                <ScanLine className="h-4 w-4" /> Inspection light / 5600K
              </div>
              <div className="absolute bottom-6 left-6 max-w-xs sm:bottom-8 sm:left-8">
                <p className="font-display text-2xl font-semibold leading-[.95] tracking-[-.03em] text-[#f2eee5]">
                  Clarity is a process.
                </p>
                <p className="mt-2 text-sm leading-6 text-white/65">
                  No shortcuts disguised as shine.
                </p>
              </div>
            </div>
          </div>
        </section>

        <section id="services" className="scroll-mt-20 py-20 sm:py-28">
          <div className="mx-auto max-w-screen-2xl px-5 sm:px-8 lg:px-12">
            <div className="grid gap-7 lg:grid-cols-[minmax(0,1.2fr)_minmax(300px,.8fr)] lg:items-end">
              <div>
                <p className="font-mono text-xs text-highlight">02 / The services</p>
                <h2 className="mt-5 max-w-3xl font-display text-4xl font-semibold leading-[.88] tracking-[-.055em] text-[#f2eee5] sm:text-6xl">
                  Every surface.
                  <br />
                  <span className="text-metallic">Considered.</span>
                </h2>
              </div>
              <p className="max-w-xl border-l border-border-strong pl-5 text-sm leading-7 text-muted-foreground">
                Purpose-built care for road, collection, and circuit. Choose the outcome, and we’ll
                shape the protocol around the car.
              </p>
            </div>
            <div className="mt-12 grid gap-4 md:grid-cols-2">
              {services.map((service, index) => (
                <motion.article
                  key={service.number}
                  initial={{ opacity: 0, y: 18 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: "-60px" }}
                  transition={{ delay: reduced ? 0 : index * 0.06 }}
                  className="group relative min-h-[330px] overflow-hidden border border-border bg-card sm:min-h-[380px]"
                >
                  <img
                    src={service.image}
                    alt={service.alt}
                    width={1600}
                    height={1000}
                    loading="lazy"
                    className="absolute inset-0 h-full w-full object-cover grayscale-[.12] transition-transform duration-700 group-hover:scale-[1.04]"
                  />
                  <div className="absolute inset-0 bg-[linear-gradient(0deg,rgba(8,9,11,.96),rgba(8,9,11,.16)_72%)]" />
                  <div className="relative flex h-full min-h-[330px] flex-col justify-between p-6 sm:min-h-[380px] sm:p-8">
                    <div className="flex items-center justify-between text-[10px] font-mono tracking-[.18em] text-highlight">
                      <span>{service.number}</span>
                      <Sparkles className="h-4 w-4" />
                    </div>
                    <div className="max-w-md">
                      <h3 className="font-display text-2xl font-semibold leading-[.95] tracking-[-.03em] text-[#f2eee5] sm:text-3xl">
                        {service.title}
                      </h3>
                      <p className="mt-3 max-w-sm text-sm leading-6 text-white/65">
                        {service.description}
                      </p>
                    </div>
                  </div>
                </motion.article>
              ))}
            </div>
          </div>
        </section>

        <section className="border-y border-border bg-surface py-16 sm:py-20">
          <div className="mx-auto grid max-w-screen-2xl gap-8 px-5 sm:px-8 md:grid-cols-3 lg:px-12">
            {[
              ["01", "Inspect", "We read the paint under the right light before touching it."],
              ["02", "Correct", "We remove what distracts and preserve what makes the car yours."],
              ["03", "Protect", "We finish with a surface that stays composed beyond day one."],
            ].map(([number, title, copy]) => (
              <div key={number} className="border-l border-highlight/60 pl-5">
                <p className="font-mono text-xs text-highlight">{number}</p>
                <h3 className="mt-4 font-display text-xl font-semibold leading-[.95] tracking-[-.02em] text-[#f2eee5]">
                  {title}
                </h3>
                <p className="mt-2 text-sm leading-6 text-muted-foreground">{copy}</p>
              </div>
            ))}
          </div>
        </section>

        <section id="contact" className="scroll-mt-20 bg-[#070b13] py-20 sm:py-28">
          <div className="mx-auto grid max-w-screen-2xl gap-12 px-5 sm:px-8 lg:grid-cols-[1fr_auto] lg:items-end lg:px-12">
            <div>
              <p className="font-mono text-xs text-highlight">03 / Contact</p>
              <h2 className="mt-5 max-w-3xl font-display text-5xl font-semibold leading-[.88] tracking-[-.055em] text-[#f2eee5] sm:text-7xl">
                Start with
                <br />
                <span className="text-metallic">the finish.</span>
              </h2>
              <p className="mt-7 max-w-lg text-sm leading-7 text-muted-foreground">
                No forms. No automated booking flow. Reach the studio directly and we’ll talk
                through the right next step for your car.
              </p>
            </div>
            <div className="min-w-[280px] border-t border-border-strong pt-6 text-sm sm:min-w-[340px]">
              <a
                href={telHref}
                className="flex items-center gap-3 py-2 text-foreground transition-colors hover:text-highlight"
              >
                <Phone className="h-4 w-4 text-highlight" /> {studioContact.phone}
              </a>
              <a
                href={mailHref}
                className="flex items-center gap-3 py-2 text-foreground transition-colors hover:text-highlight"
              >
                <Mail className="h-4 w-4 text-highlight" /> {studioContact.email}
              </a>
              <div className="flex items-start gap-3 py-2 text-muted-foreground">
                <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-highlight" />{" "}
                <span>{studioContact.address}</span>
              </div>
              <div className="mt-5 flex items-center gap-3 border-t border-border pt-5 text-xs uppercase tracking-[.14em] text-muted-foreground">
                <ShieldCheck className="h-4 w-4 text-highlight" /> {studioContact.hours}
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t border-border bg-surface py-8">
        <div className="mx-auto flex max-w-screen-2xl flex-col gap-3 px-5 text-xs text-muted-foreground sm:flex-row sm:items-center sm:justify-between sm:px-8 lg:px-12">
          <span className="flex items-center gap-2 font-display font-bold uppercase tracking-[.18em] text-foreground">
            <img src={logoCompact} alt="" className="h-9 w-9 object-contain" />
            Apex Detail Lab
          </span>
          <span>Precision over compromise. © 2026</span>
        </div>
      </footer>
    </div>
  );
}
